---
name: zerosoc-triage
description: Triage a security alert under the ZeroSOC Framework (Phase 2.a). Selects the domain triage playbook, enriches the entities, tags every observation Malicious or Benign with a confidence, applies the coverage rule to decide Close (False Positive, Benign, Duplicate) or Promote, and produces a conformant Triage Note plus the Triage to Investigation contract. Use when an alert, a detection, a user report or any suspected-incident intake needs a disposition.
license: Apache-2.0
metadata:
  version: "0.4.1"
  framework: "zerosoc-framework@e5f16f8 (2026-10-16)"
  status: draft
  author: ZeroSOC
---

# ZeroSOC Triage (Phase 2.a)

Object: the **Alerts** of one Case. Outcome: exactly one of **Close** or **Promote**. There is no
"escalate". The method is the framework's; this skill sequences it, runs the deterministic parts as
scripts, and leaves judgment where the framework leaves it. Paths are relative to this skill's directory.

Read once per session, not per alert: [Detection & Analysis §1](references/framework/03-Processes/02-detection_and_analysis.md)
(the method) and the confidence table in [Definitions §7](references/framework/01-Foundation/definitions.md).
Read per alert: the playbook section the script prints.

## When to use

- A Security Alert (`Detection Finding [2004]`, `severity_id` at least Low) aggregated into a Case
  (`Incident Finding [2005]`). Signals (Informational) never trigger triage; consult them during it.
- An out-of-band report (user, IT ticket, CERT or vendor notice): register it first as an Alert and a Case
  (§5), then triage it here. Do not build a side process.
- Not for hunt-found activity: that enters Investigation directly (§4.3).

## Inputs

- The Case with its Alerts (id, type, entity, tool confidence or severity) and **what each Alert asserts
  about the threat**: its techniques, the threat name and family, the detection source and detector, the
  remediation state of its entities, the description and the recommended actions (§1.1).
- The capability binding `zerosoc.capabilities.json` (see the repository's `capabilities/` folder): it
  resolves capability classes to tools and states which `required_data_sources` are available.
- Access to the enrichment capability classes: `reputation.multi_engine`, `url.detonation`,
  `malware.repository`, `domain.registration`, `decode`, `asset.cmdb`, `identity.directory`,
  `soc.knowledge_base`, `cases.store`, and the telemetry classes for scope queries.

## Procedure

1. **Reception** (§1.1). Correlate to an open Case on the same host, identity, IP or operation (one
   request or job identifier) and append rather than open a new Case; consolidate repeats of one alert
   type from one source in the window into a summary signal (throttled alerts never enter triage). A
   shared service identity (built-in principals, the cloud provider's own service identities, a service
   account the Knowledge Base records as shared) is on its own no key for either: it stays an entity of
   the Case. Set `status_id` to In Progress. Then **read the
   alerts**: detection logic, key fields, the relationships between aggregated alerts and entities. Form a
   first impression that directs the enrichment. Re-read the Case before every later step: tools append
   alerts and change severity while you work.
2. **Extract the evidence inventory.** Before any enrichment, list every entity the source attaches to
   the Case's alerts (devices, identities, processes with PID and creation time, files with hashes,
   addresses, URLs, registry keys, mailboxes), paging through every alert, as `evidence.json`. Run
   `python3 scripts/evidence_inventory.py evidence.json --source-count N`, where N is the number of
   distinct evidence items the source itself shows for the Case (its list of unique entities, not its
   rows per alert). It removes duplicates, joins each row to its device and prints the `evidence_inventory`
   object for the ledger (`--json` adds the entities, for its `entities`). A mismatch is recorded and
   visible in every later script output: extract the rest, or state in the Note why it cannot be. When
   the source shows no count, record it as unverified. When a tool rebuilt N from the same alerts' evidence
   because the source shows no count of its own, pass `--source-basis reproduction`: a match against it is
   recorded as unverified, because a count made from the same rows cannot show a missing one. The Note's
   Summary states the figures, as verified only against the source's own count ("31 of 31 entities
   extracted"; otherwise "31 entities extracted, unverified").
   When the inventory holds processes, run `python3 scripts/process_chain.py evidence.json --alerts alerts.json`
   for the parent/child lineage the [Artifact enrichment](references/framework/04-Playbooks/99-Shared/sub_enrichment_artifact.md)
   produces: one chain per alert, each process under its ancestors, as an alert story is read (`--case` joins
   the Case's alerts into one chain per device). Read the command lines, not only the names: they carry the
   objective, and the layers of encoding over them are part of the observation: a command hidden behind one
   layer is read for its intent, each further layer is a deliberate choice, and decoding stops at five.
   Two deployments, told apart by the binding, not by assumption:
   - **The endpoint class carries process telemetry.** Query the Case's devices and window for process
     creations (`device`, `pid`, `created`, `name`, `command_line`, `parent_pid`, `parent_created`) and pass
     them with `--telemetry telemetry.json`: the ancestors the alerts never cited are reconstructed and marked
     as coming from telemetry, and the chain is complete up to the retention window.
   - **It carries alert evidence only.** The chain holds what the alerts cited; a parent outside it is a
     **lineage gap**, never matched on the PID alone and never guessed. Gaps are normal here, not a failure:
     record them, and never argue from a lineage the evidence does not support. An alert whose evidence names
     no process has no chain, whatever the console draws from its own telemetry.
3. **Read what the detection asserts** (§1.1 names the six inputs, what each is for, and what to do
   with it; this step only sequences them). Before any enrichment, run
   `python3 scripts/alert_metadata.py alerts.json --bindings zerosoc.capabilities.json --evidence evidence.json --json`:
   it reads them under the field names the deployment's map declares and records what the source did not
   supply. Put the printed object in the ledger as `detection_metadata` — every later script reads it
   from there and the Note renders it — then:
   - Take the **techniques** to step 4: they are one input to the alert type and to the candidate
     Incident Categories (`scripts/select_playbook.py --technique T1003` says what the framework's tables
     make of one, a sub-technique falling back to its parent). One the tables do not hold widens nothing,
     and is recorded on the Case and named in the Note rather than dropped or renamed.
   - Take the **threat name and family** to step 6: they direct the enrichment and seed the hypotheses.
   - **The recommended actions are context** (§1.5): read them as a set — the same instruction is
     one instruction however many alerts published it — and **use the ones that bear on this Case**.
     What you run is an observation like any other, tagged on the evidence it returned, with the
     recommendation named in the observation's `analytic`. Nothing is recorded about the rest, and
     nothing asks what became of each: the source mixes **checks** with **response actions**
     — isolate the device, reset the password, block the address — and a response action is not
     triage's to perform, so answering for one is answering for work that did not happen.
   - Aim the checks of step 6 where the **remediation state** leaves them: at the entities the source left
     **active** first, and at what a block does not answer — how the entity arrived, what ran before it
     was stopped, whether the same thing is elsewhere. The state is recorded, never weighed (§1.5).
   What an alert does not carry, the script lists under its `absent`.

4. **Choose each alert's type, and the playbook sections.** Read the
   [Alert Type taxonomy](references/framework/02-Taxonomy/alert_types.md) and give every alert the type that
   describes **what its detection fires on**: its description, its evidence, its techniques and what
   detected it. The title is the source's name for the detection and decides nothing; the type's
   *Distinct from* clause separates it from its neighbours. The type's domain is the one the taxonomy files
   it under, so the alerts of one Case may open the playbooks of several domains. Write the type on the
   alert as `alert_type`. An alert no type describes — a source's correlation, attribution or containment
   record states a conclusion rather than a behaviour — carries `no_type_reason` instead, and its checks come from
   the domain's Alert Catalog and §1.2–§1.5 directly. Then, for each type you chose, run:
   `python3 scripts/select_playbook.py --domain Endpoint --alert-type "Malware / loader execution" --bindings zerosoc.capabilities.json`.
   It prints the playbook version, the required data sources with their availability, the **visibility
   gaps** to record, the section's candidate Incident Categories and only the per-alert section you need.
   Record the selection in the ledger (`playbook`, `playbook_version`, `domain`; for a Case whose alerts
   span domains, the domain of most of them, and the others' playbooks in the Note's Provenance): a Case
   whose playbook is not recorded cannot be reproduced. The candidate Incident Categories are yours to
   propose, in the order the Case points at them: start from the sections' own, and add those the
   techniques of step 3 point at. The rules you are held to while you choose are
   [rules/types.md](rules/types.md).
   The rules you are held to while you run the checks are [rules/checks.md](rules/checks.md), given to any
   executor as they stand (`$language` in them is the language the deployment writes in).
5. **Start the ledger.** Create `ledger.json` (format in `scripts/triage_decide.py`) with the
   `evidence_inventory` object of step 2 and the `detection_metadata` of step 3. Build the alerts with
   `python3 scripts/alert_types.py alerts.json --json`, each alert carrying the `alert_type` or the
   `no_type_reason` of step 4: it refuses a type the taxonomy does not hold, and collapses the same type on
   the same entity to the strongest alert, so the rule below counts it once; an alert no type describes
   keeps its title as its type. `python3 scripts/source_profile.py --bindings zerosoc.capabilities.json --json`
   prints the ledger's `source_profile` object and the source's entry for the Case's `provenance.products`:
   a **local override** of the shipped profile is recorded there and named in the Note's Provenance. Each independent
   alert is the first Malicious observation at the tool's confidence, or at the level its severity maps to
   (Informational/Low → Low, Medium → Medium, High/Critical → High). Same type on the same entity counts
   once.
6. **Enrich** (§1.2–§1.3), starting from what the detection already asserted rather than repeating it: a
   family it named is looked up for its behaviour, not re-attributed, and a question it has already
   answered is recorded with the detection as its source and asked again only where the decision turns on
   it and the answer can be checked independently. Go through the playbook's *Enrich entities* links (the `99-Shared` sub-playbooks;
   carry back their **Produces** outputs by name) and its numbered **Checks**. Query threat intelligence,
   the asset inventory, the directory, the SOC Knowledge Base, prior Cases, the 30-day history, lateral
   scope and the campaign check. **Egress rule**: only hashes and already-public IPs and domains leave the
   environment; never files, full URLs or message bodies; detonation only in an isolated sandbox.
7. **Tag every result** as the playbook prescribes: `Malicious` or `Benign` at Low, Medium or High
   (Definitions §7: High establishes the side alone, Medium is a strong signal needing a second, Low is
   consistent but common in normal operation). A result that bears on neither side is context, untagged.
   List in the ledger each result that carried no information (a lookup that knows nothing of the
   indicator, a search that finds no approval, a lookup not answered) under `no_information_refs`, and each
   check that covered the question and found nothing under `scoped_negative_refs`: the decision script gives
   the first no weight on either side, whatever was tagged on it, and reads the second like any result (§2.4).
   A `Benign (High)` observation is one that **explains** an alert: an approved exception or documented
   change in the Knowledge Base, an authorized test window covering the host and time, a known-benign
   recurrence with the same parameters. Check the playbook's **False Positive conditions** (the detection
   misfired) and **Benign conditions** (authorized activity that legitimately matches) and record which
   one applies, as they lead to different verdicts. Name in `about` the entities a Benign observation rests
   on: it covers every alert citing them. A prior Case's verdict is context, never a verdict: verify its
   reasoning applies to *this* Case. A campaign across many entities is one Case, at the campaign's severity.
8. **Classify** (§1.4). Validate or override the source `severity_id` from asset criticality, identity
   privilege and blast radius, and state why. Record `impact_id` only when already known; never guess.
9. **Decide** by the coverage rule: `python3 scripts/triage_decide.py ledger.json`. It repeats what the source already
   neutralized, so that no Case is closed because everything in it was blocked. The script closes
   only when no Malicious observation exists beyond the alerts *and* the Benign observations cover every alert
   (a High alert only by a `Benign (High)` observation; a Low or Medium alert by Benign weights summing above
   its own); otherwise it promotes, including when there is no observation at all. It also computes the
   confidence leaving triage. For a **Duplicate**, first validate all
   four criteria of §1.5 (matching core entities, overlapping timeline, active master Case, evidence
   merged), set `duplicate_of` in the ledger, and never treat the same alert on a different entity as a
   duplicate. Checklist before promoting or closing: can you say in one sentence, with evidence, why
   the activity is or is not suspicious? If not, gather more.
10. **Write the Triage Note.** The Note renders the Case and holds no state of its own: everything it shows is already
   on the Case, sampled at this gate. `python3 scripts/note_elements.py --kind triage` prints the elements in order
   and what each must contain, and `--note note.json` — the ledger with one field per element beside it — checks the
   Note against the framework's rules. It reports what the framework requires as **failures**, and a failure is
   the only thing it reports: the Note may not be written while one stands. The script renders the
   **structure** and runs the **checks**; the prose is
   yours ([rules/note-prose.md](rules/note-prose.md)). The canonical element list is [Detection & Analysis
   §1.6](references/framework/03-Processes/02-detection_and_analysis.md), and the order is part of it —
   **Summary** (what happened and when, which entities were involved and who acted on whom, and the root cause
   where found — how it is known and how sure you are, in prose, which is not `confidence_id`); **Classification**
   (severity, confidence, impact when known, the candidate categories, and the decision: Close or Promote, with
   `verdict_id` on a Close and the master Case id on a Duplicate); **Rationale** (the coverage rule applied in one or
   two sentences); **Observations** (a table, alerts first, each with its tag, **what produced it** — the check is the
   Observation's `analytic` — and the events it rests on by OCSF identifier; each **Alert** also renders what its
   detection asserted: its techniques as `ID (Name)`, the threat name and family, the detection source and detector,
   and the remediation state of each entity it names; a **recommended action you ran** renders as the Observation it
   produced, naming the recommendation it came from, and one you did not run renders nowhere); **Case Timeline**
   (what happened, as far as triage establishes it: the Alerts, the actions your Observations establish, and the
   response actions that ran, the source's own remediation included. Triage compiles it and a Case closed here keeps
   it, so it is never "None.": give the ledger one `detection` entry per Alert, timed when its activity began, one
   `action` entry per remediation that ran, and `first_seen` with `"timeline": true` on each Observation that
   establishes something that happened; `python3 scripts/timeline.py ledger.json --json` orders them and fails what
   it cannot place. Your checks are not entries: each is the Observation it produced); **Response Actions**
   (the remediation the Case carries in one place: each Remediation Activity it references, with the entity it acted on
   and whether it succeeded, and each open ticket it raised, with its kind — a remediation the source performed before
   you opened the Case renders here too; write "None." when it carries neither); **Visibility Gaps** (or
   "None."); **Provenance** (playbook path and version, executor classes, capability classes invoked, Case id). There is no Actions Taken element and no
   References element: the check that produced an Observation is rendered beside that Observation, and so are the events it
   cites.
   Name it `triage_note_<case-id>_<YYYYMMDD-HHMM>`.
   Write technique codes as `ID (Name)`: `scripts/alert_metadata.py` renders the ones the framework's
   tables name, and for the rest write the ATT&CK or ATLAS name. §1.6 states this as a SHOULD and it is
   guidance to you here — nothing reads the Note back to check its spelling.
   Summarize evidence in the Note and never paste raw logs — what the Note summarizes, the Case
   keeps: the events each Observation rests on stay on the Case and the Note cites them
   ([Case Schema §3](references/framework/02-Taxonomy/case_schema.md)).
11. **Emit.** On Close: `verdict_id` 1 (False Positive; also a `tuning` ticket to Phase 1), 5 (Benign; also an
    `exception` ticket — the Knowledge Base entry you propose and a person confirms — unless the Knowledge
    Base already holds it) or 10 (Duplicate, with `master_case_uid`). Which of
    1 and 5 is the rule's, and `triage_decide.py` prints it: each covering Benign observation carries in the
    ledger the kind of the condition it named, read off the list the condition is in — `"condition":
    "false_positive"` or `"benign"` — and the Case closes as Benign when the covering observation of the
    highest confidence names a Benign condition, as False Positive otherwise, no condition named included
    ([Detection & Analysis §1.5](references/framework/03-Processes/02-detection_and_analysis.md)). A
    Malicious observation resting on the alert records alone is set aside as a restatement of the alerts
    (`restated_alerts`) and never promotes by itself. On
    Promote: `verdict_id` stays 0 and the Case carries the **Triage → Investigation contract** of
    [Playbook Architecture §5](references/framework/04-Playbooks/playbook_architecture.md): `uid`,
    `status_id`, `severity_id`, `confidence_id`, `impact_id` when known, `start_time`, `observables`,
    `finding_info_list`, `attacks`, `candidate_incident_categories`, `entry_path`, `master_case_uid`
    when correlated, `visibility_gaps`, `provenance`, `desc`, and `notes` carrying the Triage Note.
    The contract states which fields must be populated at the boundary; one Case object crosses every
    phase, so nothing is copied. Then invoke the `zerosoc-investigation` skill.

## Governance

- Request permissions just in time for each query and let them expire when it completes; attribute every
  call to the Case id ([Guardrails §1](references/framework/07-Governance/agentic_guardrails.md)).
- A Crown Jewel asset or a privileged identity in scope makes a **human** the assignee from that moment
  (Guardrails §3, `handover_reason`); keep enriching and proposing, the human decides.
- Record token use per model invocation with the Case id; a budget exhaustion is not a failure: apply
  the coverage rule to the evidence at hand (Guardrails §5).
- Never close because similar Cases were closed before; never promote out of fear; never close to clear
  the queue.

## Completion criteria

Exactly one outcome recorded; the Triage Note conformant (every tagged Observation has an event reference,
what each detection asserted rendered with its Alert, each recommended action you ran rendered as the
Observation it produced, Visibility Gaps stated); on Promote the contract populated; on Close the verdict and its
emission done.
A Note whose Observations lack event references, or a close that leaves an alert uncovered, is
non-conformant and voids the run.
