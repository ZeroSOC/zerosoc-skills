# Generated framework references

Source: zerosoc-framework@411fe936a9761fa3c41726f81020606331c382b8 (Apache-2.0).

Do not edit these files; regenerate with `python3 tools/build_references.py`.


- `references/framework/01-Foundation/definitions.md`
- `references/framework/02-Taxonomy/alert_types.md`
- `references/framework/02-Taxonomy/case_schema.json`
- `references/framework/02-Taxonomy/case_schema.md`
- `references/framework/02-Taxonomy/incident_categories.md`
- `references/framework/03-Processes/02-detection_and_analysis.md`
- `references/framework/03-Processes/03-response.md`
- `references/framework/04-Playbooks/02-Investigation-Response/00-generic.md`
- `references/framework/04-Playbooks/02-Investigation-Response/01-phishing.md`
- `references/framework/04-Playbooks/02-Investigation-Response/02-bec.md`
- `references/framework/04-Playbooks/02-Investigation-Response/03-ransomware.md`
- `references/framework/04-Playbooks/02-Investigation-Response/04-dos.md`
- `references/framework/04-Playbooks/02-Investigation-Response/05-commodity_malware.md`
- `references/framework/04-Playbooks/02-Investigation-Response/06-identity_credential_attack.md`
- `references/framework/04-Playbooks/02-Investigation-Response/07-web_app_exploitation.md`
- `references/framework/04-Playbooks/02-Investigation-Response/08-infrastructure_compromise.md`
- `references/framework/04-Playbooks/02-Investigation-Response/09-insider_threat.md`
- `references/framework/04-Playbooks/02-Investigation-Response/10-supply_chain.md`
- `references/framework/04-Playbooks/02-Investigation-Response/11-data_breach_exfiltration.md`
- `references/framework/04-Playbooks/02-Investigation-Response/12-resource_hijacking.md`
- `references/framework/04-Playbooks/02-Investigation-Response/13-destructive_wiper.md`
- `references/framework/04-Playbooks/02-Investigation-Response/14-ot_ics.md`
- `references/framework/04-Playbooks/02-Investigation-Response/15-ai_ml_system.md`
- `references/framework/04-Playbooks/99-Shared/sub_enrichment_artifact.md`
- `references/framework/04-Playbooks/99-Shared/sub_enrichment_asset.md`
- `references/framework/04-Playbooks/99-Shared/sub_enrichment_email_message.md`
- `references/framework/04-Playbooks/99-Shared/sub_enrichment_identity.md`
- `references/framework/04-Playbooks/99-Shared/sub_enrichment_network.md`
- `references/framework/04-Playbooks/README.md`
- `references/framework/04-Playbooks/playbook_architecture.md`
- `references/framework/06-Deliverables/investigation_note.md`
- `references/framework/07-Governance/agentic_guardrails.md`
- `references/framework/07-Governance/agentic_supervision.md`
